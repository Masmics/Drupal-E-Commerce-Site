<?php
/**
 * @file
 * Extend template implementation to display a raw block.
 */

?>
<?php print $content; ?>
